1. Compile the code using gcc -std=gnu99 -o myCounter myCounter.c -pthread

2. This will create the executable myCounter

3. You can then run ./myCounter