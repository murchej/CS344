1. Compile the code using $ make

2. Then enter $ make test

3. Vscode is not happy with libraries used but it still compiles and runs on the server.

4. Enter $ make clean as to not make more files than necessary.
