1. Clear out any old executables with "make clean"

2. Compile with "make"

3. Run script using "./p5testscript RANDOM_PORT1 RANDOM_PORT2 > mytestresults 2>&1"